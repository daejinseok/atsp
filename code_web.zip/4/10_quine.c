int main() {char c = '"'; char *s = "int main() {char c = '%c'; char *s = %c%s%c; printf(s, c, c, s, c);return 0;}"; printf(s, c, c, s, c);return 0;}
